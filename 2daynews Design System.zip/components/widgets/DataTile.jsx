import React from 'react';

/** Utility data tile — gold rate, market index, weather, cricket score. Mono numerals, delta arrow. */
export function DataTile({ kind = 'gold', label, value, unit, sub, delta, style = {} }) {
  const KINDS = {
    gold: { color: 'var(--cat-gold)', icon: '⬤' },
    market: { color: 'var(--cat-business)', icon: '⬤' },
    weather: { color: 'var(--cat-weather)', icon: '⬤' },
    cricket: { color: 'var(--cat-sports)', icon: '⬤' },
  };
  const k = KINDS[kind] || KINDS.gold;
  const up = typeof delta === 'number' ? delta >= 0 : null;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, padding: 12, minWidth: 130, background: 'var(--surface-card)', borderRadius: 'var(--r-md)', border: '1px solid var(--border-hairline)', boxShadow: 'var(--shadow-card)', ...style }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{ width: 7, height: 7, borderRadius: '50%', background: k.color }} />
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 11, letterSpacing: 'var(--tracking-eyebrow)', textTransform: 'uppercase', color: 'var(--text-muted)' }}>{label}</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: 22, color: 'var(--text-strong)', letterSpacing: '-0.02em' }}>{value}</span>
        {unit && <span style={{ fontFamily: 'var(--font-body)', fontSize: 12, color: 'var(--text-muted)' }}>{unit}</span>}
      </div>
      {(sub || delta != null) && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontFamily: 'var(--font-body)', fontSize: 12 }}>
          {delta != null && (
            <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, color: up ? 'var(--success)' : 'var(--danger)' }}>{up ? '▲' : '▼'} {Math.abs(delta)}</span>
          )}
          {sub && <span style={{ color: 'var(--text-faint)' }}>{sub}</span>}
        </div>
      )}
    </div>
  );
}
