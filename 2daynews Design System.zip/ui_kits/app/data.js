// Sample content for the 2daynews app UI kit. Telugu-first hyperlocal feed (geo-fenced to AP/Telangana).
window.DN_DATA = {
  language: { code: 'te', native: 'తెలుగు', location: 'Vijayawada, AP' },
  breaking: [
    'కేబినెట్‌లో కొత్త ఐటీ పాలసీకి ఆమోదం — 2 లక్షల ఉద్యోగాల లక్ష్యం',
    'తీర జిల్లాలకు భారీ వర్ష హెచ్చరిక; మత్స్యకారులకు అలర్ట్',
    'సెన్సెక్స్ 400 పాయింట్లు లాభంతో ముగింపు',
  ],
  rail: [
    { kind: 'gold', label: 'Gold 22K', value: '₹71,240', sub: 'per 10g · Hyd', delta: 180 },
    { kind: 'market', label: 'Nifty 50', value: '24,318', delta: -96 },
    { kind: 'weather', label: 'Vijayawada', value: '34°', sub: 'AQI 82 · Haze' },
    { kind: 'cricket', label: 'IND vs AUS', value: '286/4', sub: '48.2 ov' },
  ],
  sections: ['breaking', 'politics', 'cinema', 'sports', 'jobs', 'crime', 'business', 'weather', 'gold'],
  stories: [
    { id: 1, category: 'breaking', breaking: true, layout: 'hero', headline: 'తీర జిల్లాలకు భారీ వర్ష హెచ్చరిక; వారాంతంలో గాలివానలు',
      summary: 'IMD ప్రకారం రాబోయే 48 గంటల్లో బలమైన గాలులు, స్థానిక వరదల ముప్పు. మత్స్యకారులు సముద్రంలోకి వెళ్లవద్దని సూచన.',
      source: 'TV9', location: 'Vijayawada', time: '8 min', verified: true, body: [
        'భారత వాతావరణ శాఖ (IMD) ఆంధ్రప్రదేశ్ తీర జిల్లాలకు వారాంతం వరకు భారీ వర్ష హెచ్చరిక జారీ చేసింది.',
        'బంగాళాఖాతంలో ఏర్పడిన అల్పపీడనం కారణంగా గాలివానలు, స్థానిక వరదల ముప్పు ఉందని అధికారులు తెలిపారు.',
        'మత్స్యకారులు సముద్రంలోకి వెళ్లవద్దని, ప్రజలు అప్రమత్తంగా ఉండాలని ప్రభుత్వం విజ్ఞప్తి చేసింది.',
      ] },
    { id: 2, category: 'cinema', layout: 'row', headline: 'టాలీవుడ్ హీరో తదుపరి చిత్రం సంక్రాంతికి — ఫస్ట్ లుక్ విడుదల',
      summary: 'ఫెస్టివల్ సీజన్‌లో భారీ పోటీకి రంగం సిద్ధం; హైదరాబాద్‌లో చివరి షెడ్యూల్ పూర్తి.',
      source: 'Sakshi', location: 'Hyderabad', time: '1 hr', aiRewritten: true, body: [
        'ప్రముఖ టాలీవుడ్ హీరో నటిస్తున్న చిత్రం వచ్చే సంక్రాంతికి విడుదల కానుందని నిర్మాతలు ప్రకటించారు.',
        'చిత్రం చివరి షెడ్యూల్ హైదరాబాద్‌లో పూర్తయిందని, పోస్ట్ ప్రొడక్షన్ పనులు వేగంగా జరుగుతున్నాయని తెలిపారు.',
      ] },
    { id: 3, category: 'jobs', layout: 'row', headline: 'APPSC గ్రూప్-II నోటిఫికేషన్ విడుదల — 1,200 ఖాళీలు',
      summary: 'ఆన్‌లైన్ దరఖాస్తులు ఈ నెలాఖరు వరకు; పరీక్ష మార్చిలో నిర్వహణ.',
      source: '2daynews', location: 'AP', time: '2 hr', verified: true, body: [
        'ఆంధ్రప్రదేశ్ పబ్లిక్ సర్వీస్ కమిషన్ (APPSC) గ్రూప్-II పోస్టులకు 1,200 ఖాళీలతో నోటిఫికేషన్ విడుదల చేసింది.',
        'అర్హులైన అభ్యర్థులు ఈ నెలాఖరులోగా ఆన్‌లైన్‌లో దరఖాస్తు చేసుకోవాలని కమిషన్ సూచించింది.',
      ] },
    { id: 4, category: 'politics', layout: 'row', headline: 'రాష్ట్ర కేబినెట్‌లో కొత్త ఐటీ పాలసీకి ఆమోదం',
      summary: 'రానున్న ఐదేళ్లలో 2 లక్షల ఉద్యోగాల కల్పనే లక్ష్యంగా విధానం.',
      source: 'Eenadu', location: 'Amaravati', time: '3 hr', verified: true, body: [
        'రాష్ట్ర మంత్రివర్గం సమావేశంలో కొత్త ఐటీ పాలసీకి ఆమోదం లభించింది.',
      ] },
    { id: 5, category: 'sports', layout: 'compact', headline: 'హోం టెస్ట్ సిరీస్‌కు భారత జట్టు ప్రకటన',
      source: 'Cricbuzz', time: '4 hr', verified: true, body: ['రాబోయే హోం టెస్ట్ సిరీస్‌కు భారత జట్టును బీసీసీఐ ప్రకటించింది.'] },
    { id: 6, category: 'crime', layout: 'compact', headline: 'నగరంలో సైబర్ మోసం ముఠా అరెస్ట్; రూ.2 కోట్లు స్వాధీనం',
      source: 'ABN', location: 'Guntur', time: '5 hr', body: ['పోలీసులు సైబర్ మోసాలకు పాల్పడుతున్న ముఠాను అరెస్ట్ చేశారు.'] },
  ],
  explore: [
    { category: 'politics', label: 'Politics' }, { category: 'crime', label: 'Crime' },
    { category: 'cinema', label: 'Cinema' }, { category: 'sports', label: 'Sports' },
    { category: 'jobs', label: 'Jobs' }, { category: 'business', label: 'Business' },
    { category: 'education', label: 'Education' }, { category: 'health', label: 'Health' },
    { category: 'weather', label: 'Weather' }, { category: 'astrology', label: 'Astrology' },
    { category: 'gold', label: 'Gold' }, { category: 'tech', label: 'Tech' },
  ],
  panchang: { tithi: 'Dashami', nakshatra: 'Uttara', rahu: '1:30–3:00 PM', lucky: '7 · Red' },
};
