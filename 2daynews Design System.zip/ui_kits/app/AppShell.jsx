// Shared bits for the app kit: DS namespace alias, Lucide icon helper, phone chrome.
const DS = window.Ds2daynewsDesignSystem_0b44f3;

function Icon({ name, size = 20, color = 'currentColor', style = {} }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (ref.current && window.lucide) {
      ref.current.innerHTML = '';
      const el = document.createElement('i');
      el.setAttribute('data-lucide', name);
      ref.current.appendChild(el);
      window.lucide.createIcons({ attrs: { width: size, height: size, stroke: color, 'stroke-width': 2 }, nameAttr: 'data-lucide' });
    }
  }, [name, size, color]);
  return <span ref={ref} style={{ display: 'inline-flex', width: size, height: size, ...style }} />;
}

// Sticky app header: wordmark + location + language pill.
function AppHeader({ lang, onLangTap }) {
  return (
    <header style={{ position: 'sticky', top: 0, zIndex: 5, background: 'var(--surface-card)', borderBottom: '1px solid var(--border-hairline)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px var(--gutter)' }}>
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 24, letterSpacing: '-0.02em', color: 'var(--ink-900)' }}>
          <span style={{ color: 'var(--brand)' }}>2day</span>news
        </span>
        <div style={{ flex: 1 }} />
        <button onClick={onLangTap} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '6px 12px', borderRadius: 'var(--r-pill)', border: '1px solid var(--border-strong)', background: 'var(--white)', fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 13, color: 'var(--ink-800)', cursor: 'pointer' }}>
          <span style={{ fontFamily: 'var(--font-display)', color: 'var(--brand-strong)', fontWeight: 700 }}>తె</span>{lang.native}
          <Icon name="chevron-down" size={14} color="var(--ink-400)" />
        </button>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '0 var(--gutter) 10px', color: 'var(--text-muted)', fontFamily: 'var(--font-body)', fontSize: 12.5 }}>
        <Icon name="map-pin" size={13} color="var(--brand)" />
        <span style={{ fontWeight: 600, color: 'var(--ink-700)' }}>{lang.location}</span>
        <span style={{ color: 'var(--ink-300)' }}>·</span>
        <span>Hyperlocal feed</span>
      </div>
    </header>
  );
}

// Horizontally-scrolling data rail (gold / markets / weather / cricket).
function DataRail({ rail }) {
  return (
    <div style={{ display: 'flex', gap: 10, overflowX: 'auto', padding: '12px var(--gutter)', scrollbarWidth: 'none', background: 'var(--surface-sunk)' }}>
      {rail.map((d, i) => <DS.DataTile key={i} {...d} style={{ flex: '0 0 auto' }} />)}
    </div>
  );
}

// Bottom tab bar.
function BottomNav({ tab, onTab }) {
  const items = [
    { id: 'feed', icon: 'newspaper', label: 'Feed' },
    { id: 'explore', icon: 'layout-grid', label: 'Explore' },
    { id: 'utility', icon: 'gem', label: 'Utility' },
    { id: 'saved', icon: 'bookmark', label: 'Saved' },
  ];
  return (
    <nav style={{ display: 'flex', borderTop: '1px solid var(--border-hairline)', background: 'var(--surface-card)', paddingBottom: 6 }}>
      {items.map((it) => {
        const on = tab === it.id;
        return (
          <button key={it.id} onClick={() => onTab(it.id)} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, padding: '10px 0', background: 'none', border: 'none', cursor: 'pointer', color: on ? 'var(--brand)' : 'var(--ink-400)' }}>
            <Icon name={it.icon} size={22} color={on ? 'var(--brand)' : 'var(--ink-400)'} />
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: on ? 700 : 500, fontSize: 10.5 }}>{it.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

Object.assign(window, { DS, Icon, AppHeader, DataRail, BottomNav });
