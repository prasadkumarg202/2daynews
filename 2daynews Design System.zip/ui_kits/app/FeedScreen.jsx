// Main feed screen: breaking ticker → data rail → section tabs → story feed.
function FeedScreen({ data, onOpen }) {
  const [sec, setSec] = React.useState('breaking');
  const stories = sec === 'breaking' ? data.stories : (
    data.stories.filter((s) => s.category === sec).length ? data.stories.filter((s) => s.category === sec) : data.stories
  );
  return (
    <div>
      <DS.BreakingTicker label="Breaking" items={data.breaking} />
      <DataRail rail={data.rail} />
      <DS.SectionTabs value={sec} onChange={setSec} items={data.sections} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--stack-gap)', padding: 'var(--gutter)' }}>
        {stories.map((s) => (
          <DS.NewsCard key={s.id} layout={s.layout} category={s.category} breaking={s.breaking}
            headline={s.headline} summary={s.summary} source={s.source} location={s.location}
            time={s.time} verified={s.verified} aiRewritten={s.aiRewritten} onClick={() => onOpen(s)} />
        ))}
      </div>
    </div>
  );
}
window.FeedScreen = FeedScreen;
